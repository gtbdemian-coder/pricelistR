package com.mycompany.fabric_price_list;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FabricPriceListApplicationTests {

	@Test
	void contextLoads() {
	}

}
